
TITLE: 
Girly - 100% Fully Responsive One Page HTML5 Bootstrap 4 Template

AUTHOR:
DESIGNED & DEVELOPED by FreeHTML5.co

Website: http://freehtml5.co/
Twitter: http://twitter.com/fh5co
Facebook: http://facebook.com/fh5co


CREDITS:

Bootstrap
http://getbootstrap.com/

jQuery
http://jquery.com/

Parallax
http://pixelcog.github.io/parallax.js/

Demo Images:
http://unsplash.com

